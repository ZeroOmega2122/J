const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;

function makeCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < 4; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
  return s;
}

const THEMES = {
  'Animales': ['perro', 'gato', 'león', 'águila', 'delfín', 'elefante', 'jirafa', 'serpiente', 'oso', 'pingüino', 'caballo', 'tigre'],
  'Comida': ['pizza', 'hamburguesa', 'tacos', 'sushi', 'pasta', 'arroz', 'pollo', 'manzana', 'chocolate', 'helado', 'pan', 'queso'],
  'Películas': ['Avatar', 'Titanic', 'Matrix', 'Inception', 'Gladiador', 'Joker', 'Interestelar', 'Toy Story', 'El Padrino', 'Frozen', 'Shrek', 'Sonic'],
  'Deportes': ['fútbol', 'baloncesto', 'tenis', 'natación', 'béisbol', 'voleibol', 'boxeo', 'ciclismo', 'golf', 'esquí', 'rugby', 'hockey'],
  'Instrumentos': ['guitarra', 'piano', 'violín', 'flauta', 'tambor', 'trompeta', 'saxofón', 'arpa', 'batería', 'bajo', 'clarinete', 'órgano'],
  'Profesiones': ['doctor', 'ingeniero', 'profesor', 'abogado', 'cocinero', 'piloto', 'dentista', 'arquitecto', 'artista', 'detective', 'científico', 'mecánico'],
  'Tecnología': ['computadora', 'teléfono', 'internet', 'robot', 'videojuego', 'cámara', 'televisor', 'reloj', 'dron', 'coche autónomo', 'satélite', 'impresora'],
  'Biblia': ['Moisés', 'Jesús', 'David', 'Adán', 'Eva', 'Noé', 'Abraham', 'María', 'Pedro', 'Sansón', 'Goliat', 'Judas', 'Lucas', 'Mateo', 'Marcos', 'Juan'],
  'Superhéroes': ['Batman', 'Superman', 'Spiderman', 'Ironman', 'Capitán América', 'Thor', 'Hulk', 'Black Widow', 'Viuda Negra', 'Flash', 'Wonder Woman', 'Acuaman'],
  'Países': ['España', 'Francia', 'Alemania', 'Italia', 'Japón', 'China', 'Brasil', 'México', 'Canadá', 'Australia', 'Suiza', 'Noruega'],
  'Playas': ['playa', 'mar', 'arena', 'ola', 'palmera', 'coral', 'arena blanca', 'acantilado', 'bahía', 'arrecife', 'costa', 'laguna'],
  'Elementos': ['fuego', 'agua', 'tierra', 'aire', 'hielo', 'rayo', 'nieve', 'lluvia', 'viento', 'tormenta', 'nube', 'arcoíris']
};

function randomWord(theme) {
  const words = THEMES[theme] || THEMES['Animales'];
  return words[Math.floor(Math.random() * words.length)];
}

function randomWordDifferent(w, theme) {
  let tries = 0;
  const words = THEMES[theme] || THEMES['Animales'];
  while (tries++ < 20) {
    const candidate = words[Math.floor(Math.random() * words.length)];
    if (candidate !== w) return candidate;
  }
  return w + '_alt';
}

const rooms = {}; // key: code -> room object

io.on('connection', (socket) => {
  console.log('socket connected', socket.id);

  socket.on('create-room', ({ name }, cb) => {
    const code = makeCode();
    rooms[code] = {
      code,
      host: socket.id,
      players: [],
      state: 'waiting'
    };
    socket.join(code);
    const pl = { id: socket.id, name: name || 'Host', alive: true, hasSpoken: false };
    rooms[code].players.push(pl);
    io.to(code).emit('room-update', rooms[code]);
    if (cb) cb({ ok: true, code });
  });

  socket.on('join-room', ({ code, name }, cb) => {
    const room = rooms[code];
    if (!room) return cb && cb({ error: 'Sala no encontrada' });
    socket.join(code);
    room.players.push({ id: socket.id, name: name || 'Player', alive: true, hasSpoken: false });
    io.to(code).emit('room-update', room);
    if (cb) cb({ ok: true });
  });

  socket.on('start-game', ({ code, theme, keepWord = false, keepImpostor = false }, cb) => {
    const room = rooms[code];
    if (!room) return cb && cb({ error: 'Sala no encontrada' });
    const alivePlayers = room.players.filter(p => p.alive);
    if (alivePlayers.length < 1) {
      return cb && cb({ error: 'Se necesita al menos 1 jugador' });
    }
    // Save room settings chosen by host
    room.settings = { keepWord: !!keepWord, keepImpostor: !!keepImpostor };
    // Preferir un impostor distinto al anterior si hay más de uno vivo
    if (room.impostorId && alivePlayers.length > 1) {
      const candidates = alivePlayers.filter(p => p.id !== room.impostorId);
      const pick = candidates[Math.floor(Math.random() * candidates.length)];
      room.impostorId = pick.id;
    } else {
      const impostorIndex = Math.floor(Math.random() * alivePlayers.length);
      room.impostorId = alivePlayers[impostorIndex].id;
    }
    room.theme = theme || 'Animales';
    room.word = randomWord(room.theme);
    room.impostorWord = randomWordDifferent(room.word, room.theme);
    room.state = 'playing';
    console.log('Nueva partida -> theme:', room.theme, 'word:', room.word, 'impostorWord:', room.impostorWord, 'impostorId:', room.impostorId);
    room.players.forEach(p => { p.hasSpoken = false; });
    // send private words
    room.players.forEach(p => {
      if (p.id === room.impostorId) {
        io.to(p.id).emit('word', { word: room.impostorWord, role: 'impostor' });
      } else {
        io.to(p.id).emit('word', { word: room.word, role: 'player' });
      }
    });
    // set turn order
    room.turnOrder = room.players.filter(p => p.alive).map(p => p.id);
    room.turnIndex = 0;
    io.to(code).emit('game-started', { players: room.players });
    const currentId = room.turnOrder[room.turnIndex];
    const currentPlayer = room.players.find(p => p.id === currentId);
    console.log('Emitiendo your-turn a:', currentId);
    io.to(currentId).emit('your-turn');
    console.log('Emitiendo turn-info:', { playerId: currentId, playerName: currentPlayer.name });
    io.to(code).emit('turn-info', { playerId: currentId, playerName: currentPlayer.name, players: room.players });
    if (cb) cb({ ok: true });
  });

  socket.on('turn-done', ({ code }) => {
    const room = rooms[code];
    if (!room) return;
    const player = room.players.find(p => p.id === socket.id);
    if (player) player.hasSpoken = true;
    const alive = room.players.filter(p => p.alive);
    const remainingToSpeak = alive.filter(p => !p.hasSpoken);
    if (remainingToSpeak.length === 0) {
      // start voting
      room.votes = {};
      io.to(code).emit('voting', { players: room.players.filter(p => p.alive) });
      return;
    }
    // find next who hasn't spoken
    let found = false;
    for (let i = 1; i <= room.turnOrder.length; i++) {
      const idx = (room.turnIndex + i) % room.turnOrder.length;
      const candId = room.turnOrder[idx];
      const cand = room.players.find(p => p.id === candId);
      if (cand && cand.alive && !cand.hasSpoken) {
        room.turnIndex = idx;
        io.to(candId).emit('your-turn');
        io.to(code).emit('turn-info', { playerId: candId, playerName: cand.name, players: room.players });
        found = true;
        break;
      }
    }
    if (!found) {
      // fallback: start voting
      room.votes = {};
      io.to(code).emit('voting', { players: room.players.filter(p => p.alive) });
    }
  });

  socket.on('cast-vote', ({ code, targetId }, cb) => {
    const room = rooms[code];
    if (!room) return cb && cb({ error: 'Sala no encontrada' });
    room.votes = room.votes || {};
    room.votes[socket.id] = targetId;
    const alive = room.players.filter(p => p.alive);
    if (Object.keys(room.votes).length >= alive.length) {
      // tally
      const counts = {};
      Object.values(room.votes).forEach(t => { counts[t] = (counts[t] || 0) + 1; });
      const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
      const [topTarget, topCount] = entries[0];
      // Si la mayoría vota 'skip-round', pasar de ronda automáticamente
      if (topTarget === 'skip-round' && topCount > Math.floor(alive.length / 2)) {
        room.state = 'between-rounds';
        room.players.forEach(p => { if (p.alive) p.hasSpoken = false; });
        room.votes = {};
        io.to(code).emit('between-rounds', { players: room.players, nextRoundReady: true, reason: 'La mayoría votó skipear ronda.' });
      } else if (maxVotes === 1 || numWithMax > 1) {
        // Empate o todos con 1 voto: no eliminar
        room.state = 'between-rounds';
        room.players.forEach(p => { if (p.alive) p.hasSpoken = false; });
        room.votes = {};
        io.to(code).emit('between-rounds', { players: room.players, nextRoundReady: true, reason: 'Empate en la votación, nadie fue eliminado.' });
      } else if (topTarget === 'end-game') {
        const impostorAlive = room.players.some(p => p.id === room.impostorId && p.alive);
        const impostorPlayer = room.players.find(p => p.id === room.impostorId);
        if (!impostorAlive) {
          io.to(code).emit('game-end', { result: 'players-win', reason: 'Impostor ya fue eliminado', impostorName: impostorPlayer.name });
        } else {
          io.to(code).emit('game-end', { result: 'impostor-wins', reason: 'El impostor se salvó', impostorName: impostorPlayer.name });
        }
        room.state = 'ended';
      } else {
        // Eliminar solo si hay mayoría absoluta
        if (maxVotes > Math.floor(alive.length / 2)) {
          const victim = room.players.find(p => p.id === topTarget);
          if (victim) {
            victim.alive = false;
            io.to(victim.id).emit('you-eliminated', { name: victim.name });
            io.to(code).emit('player-eliminated', { id: victim.id, name: victim.name });
            io.to(code).emit('players-update', room.players);
            // Check win conditions
            const impostorAlive = room.players.some(p => p.id === room.impostorId && p.alive);
            const nonImpostorsAlive = room.players.filter(p => p.alive && p.id !== room.impostorId).length;
            if (!impostorAlive) {
              if (nonImpostorsAlive === 0) {
                io.to(code).emit('game-end', { result: 'impostor-wins', reason: 'Impostor fue el último', impostorName: room.players.find(p => p.id === room.impostorId).name });
                room.state = 'ended';
              } else {
                room.state = 'between-rounds';
                room.players.forEach(p => { if (p.alive) p.hasSpoken = false; });
                room.votes = {};
                io.to(code).emit('between-rounds', { players: room.players, nextRoundReady: true });
              }
            } else if (nonImpostorsAlive === 0) {
              io.to(code).emit('game-end', { result: 'impostor-wins', reason: 'Impostor fue el último', impostorName: room.players.find(p => p.id === room.impostorId).name });
              room.state = 'ended';
            } else {
              room.state = 'between-rounds';
              room.players.forEach(p => { if (p.alive) p.hasSpoken = false; });
              room.votes = {};
              io.to(code).emit('between-rounds', { players: room.players, nextRoundReady: true });
            }
          }
        } else {
          // No hay mayoría absoluta, nadie eliminado
          room.state = 'between-rounds';
          room.players.forEach(p => { if (p.alive) p.hasSpoken = false; });
          room.votes = {};
          io.to(code).emit('between-rounds', { players: room.players, nextRoundReady: true, reason: 'No hubo mayoría absoluta, nadie fue eliminado.' });
        }
      }
      room.votes = {};
    }
    if (cb) cb({ ok: true });
  });

  socket.on('next-round', ({ code }, cb) => {
    const room = rooms[code];
    if (!room || room.host !== socket.id) return cb && cb({ error: 'No autorizado' });
    const alivePlayers = room.players.filter(p => p.alive);
    if (alivePlayers.length < 2) {
      return cb && cb({ error: 'Faltan jugadores' });
    }
    // El impostor no cambia entre rondas
    // Solo cambia la palabra si el ajuste lo permite
    const keepWord = room.settings && room.settings.keepWord;
    if (!keepWord) {
      room.word = randomWord(room.theme);
      room.impostorWord = randomWordDifferent(room.word, room.theme);
    }
    room.state = 'playing';
    console.log('Siguiente ronda -> theme:', room.theme, 'word:', room.word, 'impostorWord:', room.impostorWord, 'impostorId:', room.impostorId);
    room.players.forEach(p => { p.hasSpoken = false; });
    room.players.forEach(p => {
      if (p.id === room.impostorId) {
        io.to(p.id).emit('word', { word: room.impostorWord, role: 'impostor', theme: room.theme });
      } else {
        io.to(p.id).emit('word', { word: room.word, role: 'player', theme: room.theme });
      }
    });
    room.turnOrder = room.players.filter(p => p.alive).map(p => p.id);
    room.turnIndex = 0;
    io.to(code).emit('game-started', { players: room.players });
    const currentId = room.turnOrder[room.turnIndex];
    const currentPlayer = room.players.find(p => p.id === currentId);
    io.to(currentId).emit('your-turn');
    io.to(code).emit('turn-info', { playerId: currentId, playerName: currentPlayer.name, players: room.players });
    if (cb) cb({ ok: true });
  });

  socket.on('disconnect', () => {
    // remove from rooms
    for (const code of Object.keys(rooms)) {
      const room = rooms[code];
      const idx = room.players.findIndex(p => p.id === socket.id);
      if (idx !== -1) {
        const wasHost = room.host === socket.id;
        room.players.splice(idx, 1);
        io.to(code).emit('room-update', room);
        if (room.players.length === 0) {
          delete rooms[code];
        } else if (wasHost) {
          room.host = room.players[0].id;
          io.to(code).emit('host-changed', { newHost: room.host });
        }
      }
    }
  });
});

server.listen(PORT, () => {
  console.log('Server listening on', PORT);
});

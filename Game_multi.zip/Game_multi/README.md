# Impostor - Juego web (prototipo)

Proyecto mínimo para jugar "Impostor" en varios teléfonos navegando a la misma sala.

Características:
- Crear sala / Unirse por código
- Asignar palabra a todos y palabra diferente al impostor
- Turnos: cada jugador recibe notificación sonora en su teléfono
- Votación para eliminar o votar "Terminar: impostor no está"
- Condiciones de fin: jugadores ganan si eliminan al impostor o aciertan que no está; impostor gana si sobrevive hasta paridad o si la votación de terminar es errónea

Ejecución local:

1. Abrir PowerShell en la carpeta del proyecto:

```powershell
cd "c:\Users\nicol\OneDrive - Universidad Técnica Federico Santa María\Escritorio\Game_multi"
npm install
npm start
```

2. Abrir `http://localhost:3000` en varios teléfonos / navegadores y crear o unirse a la sala con el código.

Notas y cómo mejorar:
- Actualmente el juego es un prototipo en memoria (no persistente). Para producción usar una DB.
- Se muestra la palabra del impostor en la UI para facilitar pruebas — quita esa indicación antes de usar en una partida real.
- Ajustar reglas de fin (paridad) según preferencia.

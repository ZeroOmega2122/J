const socket = io();

// Themes definition
const THEMES = {
  'Animales': ['perro', 'gato', 'león', 'águila', 'delfín', 'elefante', 'jirafa', 'serpiente', 'oso', 'pingüino'],
  'Comida': ['pizza', 'hamburguesa', 'tacos', 'sushi', 'pasta', 'arroz', 'pollo', 'manzana', 'chocolate', 'helado'],
  'Películas': ['Avatar', 'Titanic', 'Matrix', 'Inception', 'Gladiador', 'Joker', 'Interestelar', 'Toy Story', 'El Padrino', 'Frozen'],
  'Deportes': ['fútbol', 'baloncesto', 'tenis', 'natación', 'béisbol', 'voleibol', 'boxeo', 'ciclismo', 'golf', 'esquí'],
  'Instrumentos': ['guitarra', 'piano', 'violín', 'flauta', 'tambor', 'trompeta', 'saxofón', 'arpa', 'batería', 'bajo'],
  'Profesiones': ['doctor', 'ingeniero', 'profesor', 'abogado', 'cocinero', 'piloto', 'dentista', 'arquitecto', 'artista', 'detective'],
  'Tecnología': ['computadora', 'teléfono', 'internet', 'robot', 'videojuego', 'cámara', 'televisor', 'reloj', 'dron', 'coche autónomo'],
  'Biblia': ['Moisés', 'Jesús', 'David', 'Adán', 'Eva', 'Noé', 'Abraham', 'María', 'Pedro', 'Sansón'],
  'Superhéroes': ['Batman', 'Superman', 'Spiderman', 'Ironman', 'Capitán América', 'Thor', 'Hulk', 'Black Widow', 'Viuda Negra', 'Flash'],
  'Países': ['España', 'Francia', 'Alemania', 'Italia', 'Japón', 'China', 'Brasil', 'México', 'Canadá', 'Australia']
};

let currentRoom = null;
let roomCode = null;
let myId = null;
let myName = null;
let selectedTheme = 'Animales';
let isHost = false;
let currentTurn = null;
let pendingYourTurn = false;
let pendingTurnInfo = null;

// ============================================
// SOCKET EVENT LISTENERS - Registrar primero
// ============================================

socket.on('connect', () => {
  console.log('Conectado');
});

socket.on('room-update', (room) => {
  currentRoom = room;
  roomCode = room.code;
  const codeEl = document.getElementById('roomCode');
  if (codeEl) codeEl.textContent = room.code;
  
  const playersList = document.getElementById('playersList');
  if (playersList && room.players) {
    playersList.innerHTML = '';
    room.players.forEach(p => {
      const li = document.createElement('li');
      li.className = 'player-item';
      li.textContent = p.name;
      playersList.appendChild(li);
    });
  }
  
  const startBtn = document.getElementById('startBtn');
  if (startBtn) startBtn.disabled = !isHost || room.state !== 'waiting';
});

socket.on('word', (data) => {
  const wordEl = document.getElementById('wordValue');
  if (wordEl) wordEl.textContent = data.word;
});

socket.on('game-started', (data) => {
  console.log('game-started recibido');
  showGame();
  addMessage('🎮 ¡Juego iniciado!');
  // Actualizar lista de jugadores y resetear estado
  if (data.players) {
    currentRoom.players = data.players;
  }
  currentTurn = null;
  // Resetear UI de turno
  const turnNoticeBox = document.getElementById('turnNoticeBox');
  if (turnNoticeBox) turnNoticeBox.classList.remove('hidden');
  const votingArea = document.getElementById('votingArea');
  if (votingArea) votingArea.classList.add('hidden');
  const betweenEl = document.getElementById('betweenRoundsBox');
  if (betweenEl) betweenEl.classList.add('hidden');
  const iSpokeBtn = document.getElementById('iSpokeBtn');
  if (iSpokeBtn) iSpokeBtn.style.display = 'none';
  updatePlayersStatus();
});

socket.on('your-turn', () => {
  console.log('your-turn recibido');
  playBeep();
  const noticeEl = document.getElementById('turnNotice');
  if (noticeEl) {
    noticeEl.textContent = '¡Es tu turno! Di una pista';
  } else {
    pendingYourTurn = true;
    console.log('your-turn pendiente (DOM no listo)');
  }
  const iSpokeBtn = document.getElementById('iSpokeBtn');
  if (iSpokeBtn) {
    iSpokeBtn.style.display = 'block';
    console.log('Botón mostrado - display block');
  }
});

socket.on('turn-info', (data) => {
  const noticeEl = document.getElementById('turnNotice');
  const subtitleEl = document.getElementById('turnSubtitle');
  const turnCardEl = document.getElementById('turnNoticeBox');
  
  if (noticeEl) {
    // Para todos: mostrar quién está hablando
    noticeEl.textContent = '🎤 ' + data.playerName + ' está dando su pista';
    
    // Si es mi turno: mostrar mensaje especial
    if (data.playerId === socket.id) {
      noticeEl.textContent = '🎤 ¡Es Tu Turno!';
      if (subtitleEl) subtitleEl.textContent = 'Da tu pista para que los demás adivinen';
      if (turnCardEl) turnCardEl.classList.add('active');
    } else {
      if (subtitleEl) subtitleEl.textContent = 'Escucha la pista de ' + data.playerName;
      if (turnCardEl) turnCardEl.classList.remove('active');
    }
  } else {
    pendingTurnInfo = data;
    console.log('turn-info pendiente (DOM no listo)');
  }
  
  const iSpokeBtn = document.getElementById('iSpokeBtn');
  if (iSpokeBtn) {
    // Si el turno es del propio socket, mantener el botón visible; si no, ocultarlo
    if (data.playerId === socket.id) {
      iSpokeBtn.style.display = 'block';
      console.log('Turno propio: botón visible');
    } else {
      iSpokeBtn.style.display = 'none';
      console.log('Turno otro: botón oculto');
    }
  }
  currentTurn = data.playerId;
  if (data.players && Array.isArray(data.players)) {
    currentRoom.players = data.players;
  }
  updatePlayersStatus();
});

socket.on('voting', (data) => {
  document.getElementById('turnNoticeBox').classList.add('hidden');
  const votingArea = document.getElementById('votingArea');
  if (votingArea) votingArea.classList.remove('hidden');
  
  const voteList = document.getElementById('voteList');
  if (voteList && data.players) {
    voteList.innerHTML = '';
    data.players.forEach(p => {
        if (p.alive) {
          const li = document.createElement('li');
          const btn = document.createElement('button');
          btn.className = 'btn btn-vote vote-btn';
          btn.dataset.playerId = p.id;
          btn.textContent = p.name;
          li.appendChild(btn);
          voteList.appendChild(li);
        }
    });
    const liEnd = document.createElement('li');
    const btnEnd = document.createElement('button');
    btnEnd.className = 'btn btn-end-game btn-secondary';
    btnEnd.textContent = '🛑 Impostor no está aquí';
    liEnd.appendChild(btnEnd);
    voteList.appendChild(liEnd);
      // Botón Skipear ronda
      const liSkip = document.createElement('li');
      const btnSkip = document.createElement('button');
      btnSkip.className = 'btn btn-skip-round btn-secondary';
      btnSkip.textContent = '\u23ed\ufe0f Skipear ronda';
      liSkip.appendChild(btnSkip);
      voteList.appendChild(liSkip);
  }
});

socket.on('game-end', (data) => {
  const votingArea = document.getElementById('votingArea');
  if (votingArea) votingArea.classList.add('hidden');
  
  let msg = '';
  if (data.result === 'players-win') {
    msg = '🎉 ¡Encontraron al impostor! ' + (data.impostorName ? '(' + data.impostorName + ')' : '');
  } else if (data.result === 'impostor-wins') {
    msg = '🎉 ¡El impostor ganó! ' + (data.impostorName ? '(' + data.impostorName + ')' : '');
  } else {
    msg = '🎭 Partida terminada. ' + (data.reason || '');
  }
  addMessage(msg);
});

socket.on('player-eliminated', (data) => {
  addMessage('❌ ' + data.name + ' fue eliminado');
  updatePlayersStatus();
});

socket.on('you-eliminated', () => {
  playBeep();
  addMessage('⚠️ ¡Has sido eliminado!');
  updatePlayersStatus();
});

socket.on('between-rounds', (data) => {
  document.getElementById('turnNoticeBox').classList.add('hidden');
  const votingArea = document.getElementById('votingArea');
  if (votingArea) votingArea.classList.add('hidden');
  
  const betweenEl = document.getElementById('betweenRoundsBox');
  if (betweenEl) betweenEl.classList.remove('hidden');
  
  const betweenMsg = document.getElementById('betweenRoundsMsg');
  if (betweenMsg) {
    betweenMsg.textContent = '⏸️ Ronda completada. El host decidirá la siguiente ronda.';
  }
  
  const nextBtn = document.getElementById('nextRoundBtn');
  if (nextBtn) nextBtn.style.display = isHost ? 'block' : 'none';
});

socket.on('players-update', (data) => {
  if (data.players) {
    currentRoom.players = data.players;
    updatePlayersStatus();
  }
});

// Initialize theme selector
function initThemes() {
  const container = document.getElementById('themeButtons');
  if (!container) return;
  container.innerHTML = '';
  
  for (const theme in THEMES) {
    const btn = document.createElement('button');
    const isActive = (theme === selectedTheme);
    btn.className = 'btn btn-theme' + (isActive ? ' active' : '');
    btn.textContent = theme;
    btn.onclick = () => {
      document.querySelectorAll('.btn-theme').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedTheme = theme;
      console.log('Tema seleccionado: ' + selectedTheme);
    };
    container.appendChild(btn);
  }
}

// Helper functions
function showLobby() {
  document.getElementById('lobbySection').classList.remove('hidden');
  document.getElementById('roomSection').classList.add('hidden');
  document.getElementById('gameSection').classList.add('hidden');
}

function showRoom() {
  document.getElementById('lobbySection').classList.add('hidden');
  document.getElementById('roomSection').classList.remove('hidden');
  document.getElementById('gameSection').classList.add('hidden');
  initThemes();
  // Set room settings UI (only host can change)
  const keepWordCb = document.getElementById('keepWordCheckbox');
  if (keepWordCb) {
    const s = (currentRoom && currentRoom.settings) ? currentRoom.settings : { keepWord: false };
    keepWordCb.checked = !!s.keepWord;
    keepWordCb.disabled = !isHost;
  }
}

function showGame() {
  document.getElementById('lobbySection').classList.add('hidden');
  document.getElementById('roomSection').classList.add('hidden');
  document.getElementById('gameSection').classList.remove('hidden');
}

function addMessage(msg) {
  const area = document.getElementById('messages');
  if (!area) return;
  const p = document.createElement('p');
  p.className = 'message';
  p.textContent = msg;
  area.appendChild(p);
  area.scrollTop = area.scrollHeight;
}

function playBeep() {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.frequency.value = 800;
  gain.gain.setValueAtTime(0.3, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 0.2);
}

function updatePlayersStatus() {
  const area = document.getElementById('playersStatus');
  if (!area || !currentRoom) return;
  
  const room = currentRoom;
  let html = '';
  
  if (room.players && Array.isArray(room.players)) {
    room.players.forEach(p => {
      let cls = 'player-tag alive';
      if (p.eliminated || !p.alive) {
        cls = 'player-tag eliminated';
      } else if (p.id === currentTurn) {
        cls = 'player-tag alive current-turn';
      }
      
      const name = p.id === myId ? p.name + ' (Tú)' : p.name;
      html += '<span class="' + cls + '">' + name + '</span>';
    });
  }
  
  area.innerHTML = html;
}

// Event listeners for buttons
document.addEventListener('DOMContentLoaded', () => {
  const createBtn = document.getElementById('createBtn');
  if (createBtn) {
    createBtn.onclick = () => {
      const name = document.getElementById('nameInput').value.trim();
      if (!name) {
        alert('Ingresa tu nombre');
        return;
      }
      myName = name;
      socket.emit('create-room', { name }, (response) => {
        if (response && response.ok && response.code) {
          roomCode = response.code;
          currentRoom = { code: roomCode, players: [{ id: socket.id, name }], state: 'waiting' };
          myId = socket.id;
          isHost = true;
          showRoom();
          addMessage('✅ Sala creada: ' + response.code);
        }
      });
    };
  }

  const joinBtn = document.getElementById('joinBtn');
  if (joinBtn) {
    joinBtn.onclick = () => {
      const name = document.getElementById('nameInput').value.trim();
      const code = document.getElementById('codeInput').value.toUpperCase();
      if (!name || !code || code.length !== 4) {
        alert('Ingresa nombre y código válido');
        return;
      }
      myName = name;
      roomCode = code;
      socket.emit('join-room', { name, code }, (response) => {
        if (response && response.ok) {
          myId = socket.id;
          isHost = false;
          showRoom();
          addMessage('✅ Unido a sala: ' + code);
        } else {
          alert('Error: ' + (response?.error || 'No se pudo unir'));
        }
      });
    };
  }

  // ...existing code...
  if (startBtn) {
    startBtn.onclick = () => {
      if (!selectedTheme) selectedTheme = 'Animales';
      const keepWord = document.getElementById('keepWordCheckbox') ? document.getElementById('keepWordCheckbox').checked : false;
      const keepImpostor = document.getElementById('keepImpostorCheckbox') ? document.getElementById('keepImpostorCheckbox').checked : false;
      socket.emit('start-game', { code: roomCode, theme: selectedTheme, keepWord, keepImpostor }, (response) => {
        if (response && response.ok) {
          addMessage('🎮 Juego iniciado...');
        } else {
          alert('Error: ' + (response?.error || 'No se pudo iniciar'));
        }
      });
    };
  }

  const nextRoundBtn = document.getElementById('nextRoundBtn');
  if (nextRoundBtn) {
    nextRoundBtn.onclick = () => {
      socket.emit('next-round', { code: roomCode }, (response) => {
        if (response && response.ok) {
          addMessage('🔄 Nueva ronda iniciada...');
        }
      });
    };
  }

  const startBtn = document.getElementById('startBtn');
  if (startBtn) {
    startBtn.onclick = () => {
      if (!selectedTheme) selectedTheme = 'Animales';
      const keepWord = document.getElementById('keepWordCheckbox') ? document.getElementById('keepWordCheckbox').checked : false;
      socket.emit('start-game', { code: roomCode, theme: selectedTheme, keepWord }, (response) => {
        if (response && response.ok) {
          addMessage('\ud83c\udfae Juego iniciado...');
        } else {
          alert('Error: ' + (response?.error || 'No se pudo iniciar'));
        }
      });
    };
  }

  const votingArea = document.getElementById('votingArea');
  if (votingArea) {
    votingArea.addEventListener('click', (e) => {
      if (e.target.classList.contains('btn-skip-round')) {
        socket.emit('cast-vote', { code: roomCode, targetId: 'skip-round' }, (response) => {
          if (response && response.ok) {
            addMessage('\u23ed\ufe0f Votaste: "Skipear ronda"');
          }
        });
      } else if (e.target.classList.contains('vote-btn')) {
        const targetId = e.target.dataset.playerId;
        socket.emit('cast-vote', { code: roomCode, targetId }, (response) => {
          if (response && response.ok) {
            addMessage('✅ Voto emitido');
          }
        });
      } else if (e.target.classList.contains('btn-end-game')) {
        socket.emit('cast-vote', { code: roomCode, targetId: 'end-game' }, (response) => {
          if (response && response.ok) {
            addMessage('✅ Votaste: "Impostor no está aquí"');
          }
        });
      }
    });
  }
  
  initThemes();
  // aplicar eventos pendientes si llegaron antes del DOMContentLoaded
  if (pendingTurnInfo) {
    const noticeEl = document.getElementById('turnNotice');
    if (noticeEl) noticeEl.textContent = pendingTurnInfo.playerName + ' está hablando...';
    currentTurn = pendingTurnInfo.playerId;
    pendingTurnInfo = null;
    updatePlayersStatus();
  }
  if (pendingYourTurn) {
    const iSpokeBtn = document.getElementById('iSpokeBtn');
    if (iSpokeBtn) iSpokeBtn.style.display = 'block';
    pendingYourTurn = false;
  }
});
  
